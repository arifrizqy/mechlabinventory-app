<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; MechLab 2023. Dev by <a href="https://github.com/arifrizqy" target="_blank">Rizqy</a> &amp; <a href="https://github.com/RosyidMaulana" target="_blank">Rosyid</a></span>
        </div>
    </div>
</footer>